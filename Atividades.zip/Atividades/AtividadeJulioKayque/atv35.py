# Atividade 35
G = [list(map(int, input(f"Digite os 5 elementos da linha {i+1} da matriz G: ").split())) for i in range(5)]


SL = [sum(linha) for linha in G]
SC = [sum(G[i][j] for i in range(5)) for j in range(5)]


print("Somas das linhas (SL):", SL)
print("Somas das colunas (SC):", SC)