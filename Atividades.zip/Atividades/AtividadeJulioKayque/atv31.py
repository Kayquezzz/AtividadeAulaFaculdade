# Atividade 31


M = []
for i in range(5):

    while True:
        try:
            linha = list(map(int, input(f"Digite os 5 elementos da linha {i+1} da matriz (separados por espaço): ").split()))
            if len(linha) == 5: 
                M.append(linha)
                break
            else:
                print("Por favor, digite exatamente 5 números.")
        except ValueError:
            print("Entrada inválida! Certifique-se de digitar números inteiros.")


soma_linha_3 = sum(M[2])


soma_coluna_2 = sum(M[i][1] for i in range(5))


soma_diagonal_principal = sum(M[i][i] for i in range(5))


soma_diagonal_secundaria = sum(M[i][4-i] for i in range(5))


soma_total = sum(sum(linha) for linha in M)


print(f"Soma da linha 3: {soma_linha_3}")
print(f"Soma da coluna 2: {soma_coluna_2}")
print(f"Soma da diagonal principal: {soma_diagonal_principal}")
print(f"Soma da diagonal secundária: {soma_diagonal_secundaria}")
print(f"Soma de todos os elementos da matriz: {soma_total}")