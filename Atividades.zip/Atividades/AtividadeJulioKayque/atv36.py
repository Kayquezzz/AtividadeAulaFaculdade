#Atividade 36


A = [list(map(int, input(f"Digite os 13 elementos da linha {i+1} da matriz A: ").split())) for i in range(12)]


for i in range(12):
    maior = max(A[i])
    A[i] = [x / maior for x in A[i]]


for linha in A:
    print(linha)